#include <iostream>
 
#include <pcl/io/pcd_io.h>
 
#include <pcl/point_types.h>
 
#include <pcl/common/io.h>
 
#include <pcl/keypoints/iss_3d.h>
 
#include <pcl/features/normal_3d.h>
 
#include <pcl/visualization/pcl_visualizer.h>
 
#include <boost/thread/thread.hpp>
 
#include <pcl/visualization/cloud_viewer.h>
 
 
 
using namespace std;
 
 
 
int main(int, char** argv)
 
{
 
    pcl::PointCloud<pcl::PointXYZ>::Ptr cloud(new pcl::PointCloud<pcl::PointXYZ>);
 
    if (pcl::io::loadPCDFile<pcl::PointXYZ>("****", *cloud) == -1)
 
    {
 
         PCL_ERROR("Could not read pcd file\n");
 
    }
 
    cout << "initial keypoint count:" << cloud->points.size() << endl;
	;    clock_t start = clock();
 
	;    pcl::ISSKeypoint3D<pcl::PointXYZ, pcl::PointXYZ> iss;
 
    pcl::PointCloud<pcl::PointXYZ>::Ptr keypoints(new pcl::PointCloud<pcl::PointXYZ>());
 
    pcl::search::KdTree<pcl::PointXYZ>::Ptr tree(new pcl::search::KdTree<pcl::PointXYZ>());
 
 
 
    iss.setInputCloud(cloud);
 
    iss.setSearchMethod(tree);
 
    iss.setSalientRadius(***);
 
    iss.setNonMaxRadius(***);
 
    iss.setThreshold21(***); 
 
    iss.setThreshold32(***);  
 
    iss.setMinNeighbors(***); 
 
    iss.setNumberOfThreads(***); 
 
    iss.compute(*keypoints);
 
 
	clock_t end = clock();
	cout << "***:" << (double)(end - start) / CLOCKS_PER_SEC << endl;
    cout << "***: " << keypoints->points.size() << endl;
 
    pcl::io::savePCDFile("keypoints_iss_3d.pcd", *keypoints, true);
 
    boost::shared_ptr<pcl::visualization::PCLVisualizer> viewer(new pcl::visualization::PCLVisualizer("***"));
 
    pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ> single_color(cloud, 0, 225, 0);
 
    viewer->addPointCloud<pcl::PointXYZ>(cloud, single_color, "sample cloud");
 
    viewer->addPointCloud<pcl::PointXYZ>(keypoints, "sample cloud1");
 
viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 5, "sample cloud1");
 
    viewer->setPointCloudRenderingProperties(pcl::visualization::PCL_VISUALIZER_COLOR, 255, 255, 255, "sample cloud1");
 
    while (!viewer->wasStopped())
 
    {
 
         viewer->spinOnce(***);
 
         boost::this_thread::sleep(boost::posix_time::microseconds(***));
 
    }
 
    return 0;
 
 
 
}